#!/usr/bin/env python3

import math
import rclpy
import numpy as np

from phi_p3dx_navigation.main import NavigationNode


class VFHNavigator(NavigationNode):
    """
    Navegação orientada ao objetivo com VFH simplificado e subobjetivo local.

    Estratégia:
      1. Tenta ir diretamente ao objetivo final.
      2. Se a direção do objetivo estiver bloqueada, seleciona a melhor janela livre.
      3. Define o centro dessa janela como direção intermediária.
      4. Projeta um ponto intermediário a uma distância fixa x do robô.
      5. Vai até esse ponto antes de sair do modo intermediário.
      6. Ao chegar, reavalia:
         - se a direção do objetivo final a essa mesma distância x estiver livre, vai direto;
         - senão, calcula novo subobjetivo local.
    """

    def __init__(self):
        super().__init__(node_name='vfh_navigator', timer_period=0.05)

        # =========================================================
        # Navegação
        # =========================================================
        self.goal_tolerance = 0.20
        self.max_linear_speed = 0.22
        self.min_linear_speed = 0.05
        self.max_angular_speed = 0.9
        self.goal_k_ang = 1.8

        # =========================================================
        # VFH simplificado
        # =========================================================
        self.num_sectors = 36
        self.occupied_distance = 0.70
        self.sector_safety_margin = 0.12
        self.min_free_block_size = 2
        self.obstacle_enlarge_sectors = 1

        # Distância do subobjetivo local
        self.lookahead_distance = 0.80

        # Distância frontal para invalidar subobjetivo e recalcular
        self.front_recalc_distance = 0.45

        # Tolerância para considerar subobjetivo local atingido
        self.intermediate_point_tolerance = 0.12

        # Debug
        self.debug_print_interval = 2.0
        self.last_debug_time = self.get_clock().now()

        # =========================================================
        # Estado do subobjetivo intermediário
        # =========================================================
        self.has_intermediate_target = False
        self.intermediate_target_point = None   # (x, y) no mundo
        self.intermediate_target_dir = 0.0      # apenas para debug
        self.intermediate_window = None

        self.get_logger().info(
            'VFHNavigator iniciado. Envie goals pelo RViz em /goal_pose.'
        )

    # =========================================================
    # Utilidades
    # =========================================================

    def normalize_angle(self, angle: float) -> float:
        return math.atan2(math.sin(angle), math.cos(angle))

    def clamp(self, value: float, vmin: float, vmax: float) -> float:
        return max(vmin, min(vmax, value))

    def goal_angle_robot_frame(self) -> float:
        return self.normalize_angle(self.angle_to_goal())

    def clear_intermediate_target(self):
        self.has_intermediate_target = False
        self.intermediate_target_point = None
        self.intermediate_target_dir = 0.0
        self.intermediate_window = None

    def world_point_from_robot_polar(self, distance: float, angle_robot_frame: float):
        """
        Constrói um ponto no mundo a partir de uma direção no referencial do robô.
        """
        world_angle = self.theta + angle_robot_frame
        px = self.x + distance * math.cos(world_angle)
        py = self.y + distance * math.sin(world_angle)
        return (px, py)

    def set_intermediate_target(self, direction_robot_frame: float, window):
        """
        Define um ponto intermediário a uma distância fixa do robô.
        """
        self.has_intermediate_target = True
        self.intermediate_target_dir = self.normalize_angle(direction_robot_frame)
        self.intermediate_target_point = self.world_point_from_robot_polar(
            self.lookahead_distance,
            self.intermediate_target_dir
        )
        self.intermediate_window = window

    def distance_to_point(self, point) -> float:
        if point is None:
            return float('inf')
        return math.hypot(point[0] - self.x, point[1] - self.y)

    def angle_to_point(self, point) -> float:
        if point is None:
            return 0.0
        desired = math.atan2(point[1] - self.y, point[0] - self.x)
        err = desired - self.theta
        return math.atan2(math.sin(err), math.cos(err))

    # =========================================================
    # Histograma
    # =========================================================

    def build_sector_histogram(self):
        """
        Constrói histograma binário diretamente do laser:
          0 = livre
          1 = ocupado
        """
        if not self.has_laser_data():
            return np.array([]), np.array([])

        angle_min = self.laser_angle_min
        angle_max = self.laser_angle_max

        sector_edges = np.linspace(angle_min, angle_max, self.num_sectors + 1)
        sector_centers = 0.5 * (sector_edges[:-1] + sector_edges[1:])
        histogram = np.zeros(self.num_sectors, dtype=int)

        for i in range(self.num_sectors):
            a0 = sector_edges[i]
            a1 = sector_edges[i + 1]

            idx0 = int(max(0, math.floor((a0 - angle_min) / self.laser_angle_increment)))
            idx1 = int(min(
                len(self.laser_ranges) - 1,
                math.ceil((a1 - angle_min) / self.laser_angle_increment)
            ))

            if idx1 < idx0:
                histogram[i] = 1
                continue

            region = self.laser_ranges[idx0:idx1 + 1]
            finite = region[np.isfinite(region)]

            if len(finite) == 0:
                histogram[i] = 1
                continue

            min_dist = float(np.min(finite))

            if min_dist <= (self.occupied_distance + self.sector_safety_margin):
                histogram[i] = 1
            else:
                histogram[i] = 0

        # Expansão lateral da ocupação
        if self.obstacle_enlarge_sectors > 0:
            expanded = histogram.copy()
            occupied_idxs = np.where(histogram == 1)[0]

            for idx in occupied_idxs:
                start = max(0, idx - self.obstacle_enlarge_sectors)
                end = min(len(histogram) - 1, idx + self.obstacle_enlarge_sectors)
                expanded[start:end + 1] = 1

            histogram = expanded

        return sector_centers, histogram

    def find_free_intervals(self, histogram: np.ndarray):
        free_intervals = []
        start = None

        for i, value in enumerate(histogram):
            if value == 0 and start is None:
                start = i
            elif value == 1 and start is not None:
                end = i - 1
                if end - start + 1 >= self.min_free_block_size:
                    free_intervals.append((start, end))
                start = None

        if start is not None:
            end = len(histogram) - 1
            if end - start + 1 >= self.min_free_block_size:
                free_intervals.append((start, end))

        return free_intervals

    # =========================================================
    # Relação direção <-> setores
    # =========================================================

    def sector_index_of_angle(self, sector_centers: np.ndarray, angle: float):
        if len(sector_centers) == 0:
            return None
        return min(
            range(len(sector_centers)),
            key=lambda i: abs(self.normalize_angle(sector_centers[i] - angle))
        )

    def is_direction_free(self, sector_centers: np.ndarray, histogram: np.ndarray, direction: float) -> bool:
        idx = self.sector_index_of_angle(sector_centers, direction)
        if idx is None:
            return False
        return histogram[idx] == 0

    def interval_center_angle(self, sector_centers: np.ndarray, i_start: int, i_end: int) -> float:
        return float(0.5 * (sector_centers[i_start] + sector_centers[i_end]))

    def distance_goal_to_interval(self, sector_centers: np.ndarray, i_start: int, i_end: int, goal_dir: float) -> float:
        left_angle = min(sector_centers[i_start], sector_centers[i_end])
        right_angle = max(sector_centers[i_start], sector_centers[i_end])

        if left_angle <= goal_dir <= right_angle:
            return 0.0

        return min(
            abs(self.normalize_angle(goal_dir - left_angle)),
            abs(self.normalize_angle(goal_dir - right_angle))
        )

    def select_best_window_center(self, sector_centers: np.ndarray, free_intervals, goal_dir: float):
        """
        Escolhe a janela livre mais próxima da direção do objetivo
        e retorna o centro angular da janela.
        """
        if len(free_intervals) == 0:
            return None, None

        best_interval = min(
            free_intervals,
            key=lambda interval: self.distance_goal_to_interval(
                sector_centers, interval[0], interval[1], goal_dir
            )
        )

        chosen_dir = self.interval_center_angle(
            sector_centers, best_interval[0], best_interval[1]
        )

        return best_interval, chosen_dir

    # =========================================================
    # Controle
    # =========================================================

    def compute_cmd_to_direction(self, target_dir: float, front_clearance: float):
        ang_error = self.normalize_angle(target_dir)

        w = self.clamp(
            self.goal_k_ang * ang_error,
            -self.max_angular_speed,
            self.max_angular_speed
        )

        turn_factor = max(0.10, 1.0 - abs(w) / max(self.max_angular_speed, 1e-9))
        front_factor = self.clamp(front_clearance / 1.2, 0.0, 1.0)

        v = self.max_linear_speed * turn_factor * front_factor

        if abs(ang_error) < math.radians(40.0):
            v = max(v, self.min_linear_speed)
        else:
            v = 0.0

        return v, w

    def compute_cmd_to_point(self, point, front_clearance: float):
        target_dir = self.angle_to_point(point)
        return self.compute_cmd_to_direction(target_dir, front_clearance)

    def print_debug(self, goal_dir: float, mode: str, chosen_dir: float | None, chosen_window, histogram: np.ndarray):
        now = self.get_clock().now()
        elapsed = (now - self.last_debug_time).nanoseconds * 1e-9

        if elapsed < self.debug_print_interval:
            return

        hist_str = ''.join(str(int(x)) for x in histogram.tolist())
        chosen_txt = 'None' if chosen_dir is None else f'{math.degrees(chosen_dir):.1f}°'
        window_txt = 'None' if chosen_window is None else str(chosen_window)

        if self.intermediate_target_point is None:
            point_txt = 'None'
        else:
            point_txt = f'({self.intermediate_target_point[0]:.2f},{self.intermediate_target_point[1]:.2f})'

        self.get_logger().info(
            f'modo={mode} | goal={math.degrees(goal_dir):.1f}° | '
            f'alvo_dir={chosen_txt} | janela={window_txt} | '
            f'ponto={point_txt} | hist={hist_str}'
        )

        self.last_debug_time = now

    # =========================================================
    # Loop principal
    # =========================================================

    def _control_loop(self) -> None:
        if not self.has_laser_data():
            self.stop()
            return

        if not self.has_goal():
            self.stop()
            self.clear_intermediate_target()
            return

        dist_goal = self.distance_to_goal()
        goal_dir = self.goal_angle_robot_frame()

        if dist_goal <= self.goal_tolerance:
            self.stop()
            self.clear_goal()
            self.clear_intermediate_target()
            return

        # Goal fora do FOV frontal: gira até trazê-lo para frente
        if goal_dir < self.laser_angle_min or goal_dir > self.laser_angle_max:
            self.clear_intermediate_target()
            w = self.clamp(
                self.goal_k_ang * goal_dir,
                -self.max_angular_speed,
                self.max_angular_speed
            )
            self.publish_velocity(0.0, w)
            return

        sector_centers, histogram = self.build_sector_histogram()

        if len(histogram) == 0:
            self.stop()
            return

        free_intervals = self.find_free_intervals(histogram)
        front_clearance = self.get_front_distance(half_angle_deg=15.0)

        # =====================================================
        # CASO 1: já existe ponto intermediário local
        # Vai até ele. Só recalcula se surgir obstáculo frontal.
        # =====================================================
        if self.has_intermediate_target:
            dist_intermediate = self.distance_to_point(self.intermediate_target_point)

            # chegou no subobjetivo local -> libera e volta a testar goal final
            if dist_intermediate <= self.intermediate_point_tolerance:
                self.clear_intermediate_target()

            # obstáculo frontal apareceu -> recalcula
            elif front_clearance <= self.front_recalc_distance:
                self.clear_intermediate_target()

            else:
                v, w = self.compute_cmd_to_point(
                    self.intermediate_target_point,
                    front_clearance
                )
                self.print_debug(
                    goal_dir,
                    'intermediario',
                    self.intermediate_target_dir,
                    self.intermediate_window,
                    histogram
                )
                self.publish_velocity(v, w)
                return

        # =====================================================
        # CASO 2: tenta seguir diretamente ao objetivo final
        # =====================================================
        direct_free = self.is_direction_free(sector_centers, histogram, goal_dir)

        if direct_free:
            v, w = self.compute_cmd_to_direction(goal_dir, front_clearance)
            self.print_debug(goal_dir, 'direto', goal_dir, None, histogram)
            self.publish_velocity(v, w)
            return

        # =====================================================
        # CASO 3: direção do goal bloqueada
        # Define um novo ponto intermediário local a distância x
        # =====================================================
        chosen_window, intermediate_dir = self.select_best_window_center(
            sector_centers, free_intervals, goal_dir
        )

        if intermediate_dir is None:
            w = self.clamp(
                self.goal_k_ang * goal_dir,
                -self.max_angular_speed,
                self.max_angular_speed
            )
            self.publish_velocity(0.0, w)
            self.print_debug(goal_dir, 'sem_janela', None, None, histogram)
            return

        self.set_intermediate_target(intermediate_dir, chosen_window)

        v, w = self.compute_cmd_to_point(
            self.intermediate_target_point,
            front_clearance
        )
        self.print_debug(
            goal_dir,
            'novo_intermediario',
            self.intermediate_target_dir,
            self.intermediate_window,
            histogram
        )
        self.publish_velocity(v, w)


def main(args=None):
    rclpy.init(args=args)
    navigator = VFHNavigator()

    try:
        rclpy.spin(navigator)
    except KeyboardInterrupt:
        pass
    finally:
        navigator.stop()
        navigator.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()